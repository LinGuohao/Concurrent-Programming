package concurrent.labs;

import java.util.Objects;

public class Defender extends Soldier {

}
