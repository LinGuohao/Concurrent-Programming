import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

class Stock_Market {
    private int value = 0;

    public synchronized void addQuotation(int n) {
        value += n;
    }

    public synchronized int getQuotation() {
        return value;
    }
}

class Stock_Trend extends Thread {
    private String trend;
    private double risk;
    private boolean isFinished = false;

    public Stock_Trend(double r) {
        this.risk = r;
    }

    public synchronized String getTrend() {
        return trend;
    }

    public void run() {
            double value = Math.random();
            trend = risk > value ? "Decreasing" : "Increasing";
         synchronized (this) {
            try {
                notifyAll();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        try{
            Thread.sleep(500);
        }
            catch(InterruptedException e){
                e.printStackTrace();
            }
        
     
    }
}

class Company implements Callable<String> {
    private Stock_Market sm;
    private Stock_Trend st;
    private int total = 0;

    public Company(Stock_Market sm, Stock_Trend st) {
        this.sm = sm;
        this.st = st;
    }

    public String call() throws Exception {
        System.out.println("Thread Started!");
        synchronized (st) {
            for (int i = 0; i < 10; i++) {
                int value = new Random().nextInt();
                // System.out.println(value);
                if (st.getTrend() == "Increasing") {
                    total += value;
                } else {
                    total -= value;
                }
            }
        }
        synchronized(st){
            System.out.println("wait");
                st.wait();
        }
        sm.addQuotation(total);
        return total > 0 ? Thread.currentThread().getName() + " gainning " + total
                : Thread.currentThread().getName() + " losing " + total;
    }
}

public class Exam_3 {
    public static void main(String[] args) {
        Stock_Market sm = new Stock_Market();
        double risk = Math.random();
        String shortRisk = String.format("%.2f", risk);
        System.out.println("Loss probability: " + shortRisk);
        Stock_Trend st = new Stock_Trend(risk);
        st.setDaemon(true);
        st.start();
        ArrayList<FutureTask<String>> tasks = new ArrayList<FutureTask<String>>();
        for (int i = 0; i < 4; i++) {
            tasks.add(new FutureTask<String>(new Company(sm, st)));
        }

        for (int i = 0; i < 4; i++) {
            Thread t = new Thread(tasks.get(i), "Company-" + i);
            t.start();
            //st.run();
        }

        try {
            System.out.println("Status update: " + tasks.get(0).get());
            System.out.println("Status update: " + tasks.get(1).get());
            System.out.println("Status update: " + tasks.get(2).get());
            System.out.println("Status update: " + tasks.get(3).get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
        System.out.println("Stock market closing earnings: $" + sm.getQuotation() + "M");

    }
}